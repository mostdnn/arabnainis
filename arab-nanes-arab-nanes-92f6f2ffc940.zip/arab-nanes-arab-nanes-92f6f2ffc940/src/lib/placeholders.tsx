export { default as productPlaceholder } from '@assets/placeholders/product.svg';
export { default as couponPlaceholder } from '@assets/placeholders/coupon.svg';
export { default as avatarPlaceholder } from '@assets/placeholders/avatar.svg';
export { default as logoPlaceholder } from '@assets/placeholders/logo.svg';
export { default as productPlaceholderThumbnail } from '@assets/placeholders/product-placeholder-thumbnail.svg';
export { default as categoryBannerPlaceholder } from '@assets/placeholders/category-banner.png';