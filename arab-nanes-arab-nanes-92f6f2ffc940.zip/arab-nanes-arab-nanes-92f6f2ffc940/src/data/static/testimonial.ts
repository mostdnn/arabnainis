export const testimonials = [
	{
		id: 1,
		avatar: {
			src: "/assets/images/testimonials/1.jpg",
			width: 420,
			height: 420,
		},
		rating: 4,
		name: "Perry White",
		text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.",
	},
	{
		id: 2,
		avatar: {
			src: "/assets/images/testimonials/2.jpg",
			width: 420,
			height: 420,
		},
		rating: 3,
		name: "Jiniya Snow",
		text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.",
	},
	{
		id: 3,
		avatar: {
			src: "/assets/images/testimonials/3.jpg",
			width: 420,
			height: 420,
		},
		rating: 5,
		name: "Ketty Rawn",
		text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.",
	},
	{
		id: 4,
		avatar: {
			src: "/assets/images/testimonials/4.jpg",
			width: 420,
			height: 420,
		},
		rating: 5,
		name: "Amanda Johnson",
		text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.",
	},
	{
		id: 5,
		avatar: {
			src: "/assets/images/testimonials/5.jpg",
			width: 420,
			height: 420,
		},
		rating: 5,
		name: "Marvel Blu",
		text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.",
	},
	{
		id: 6,
		avatar: {
			src: "/assets/images/testimonials/2.jpg",
			width: 420,
			height: 420,
		},
		rating: 4,
		name: "Jiniya Snow",
		text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.",
	},
];
