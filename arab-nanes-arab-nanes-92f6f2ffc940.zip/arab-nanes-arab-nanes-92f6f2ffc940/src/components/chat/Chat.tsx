import React from 'react'

export default function Chat() {
  return (
    <div>
        <a className="whatsappcli" href="https://api.whatsapp.com/send?phone=01033262040" target='_blank'>
            <img src="/icons/whatsApp_icons.png" />
            </a>
    </div>
  )
}
